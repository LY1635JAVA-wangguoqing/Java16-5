package com.qhit.bean;

public class Level {
	private int easy;
	private int ordinary;
	private int difficult;
	private int easy1;
	private int ordinary1;
	private int difficult1;
	public int getEasy() {
		return easy;
	}
	public void setEasy(int easy) {
		this.easy = easy;
	}
	public int getOrdinary() {
		return ordinary;
	}
	public void setOrdinary(int ordinary) {
		this.ordinary = ordinary;
	}
	public int getDifficult() {
		return difficult;
	}
	public void setDifficult(int difficult) {
		this.difficult = difficult;
	}
	public int getEasy1() {
		return easy1;
	}
	public void setEasy1(int easy1) {
		this.easy1 = easy1;
	}
	public int getOrdinary1() {
		return ordinary1;
	}
	public void setOrdinary1(int ordinary1) {
		this.ordinary1 = ordinary1;
	}
	public int getDifficult1() {
		return difficult1;
	}
	public void setDifficult1(int difficult1) {
		this.difficult1 = difficult1;
	}
	
	
}
