package com.qhit.bean;

import java.util.HashSet;
import java.util.Set;

/**
 * Subject entity. @author MyEclipse Persistence Tools
 */

public class Subject implements java.io.Serializable {

	// Fields

	private Integer subid;
	private Direction direction;
	private Stage stage;
	private String subname;
	private Set examQuestions = new HashSet(0);
	private Set papers = new HashSet(0);
	private int count;
	// Constructors

	/** default constructor */
	public Subject() {
	}

	/** minimal constructor */
	public Subject(Integer subid) {
		this.subid = subid;
	}

	/** full constructor */
	public Subject(Integer subid, Direction direction, Stage stage,
			String subname, Set examQuestions, Set papers) {
		this.subid = subid;
		this.direction = direction;
		this.stage = stage;
		this.subname = subname;
		this.examQuestions = examQuestions;
		this.papers = papers;
	}

	// Property accessors

	public Integer getSubid() {
		return this.subid;
	}

	public void setSubid(Integer subid) {
		this.subid = subid;
	}

	public Direction getDirection() {
		return this.direction;
	}

	public void setDirection(Direction direction) {
		this.direction = direction;
	}

	public Stage getStage() {
		return this.stage;
	}

	public void setStage(Stage stage) {
		this.stage = stage;
	}

	public String getSubname() {
		return this.subname;
	}

	public void setSubname(String subname) {
		this.subname = subname;
	}

	public Set getExamQuestions() {
		return this.examQuestions;
	}

	public void setExamQuestions(Set examQuestions) {
		this.examQuestions = examQuestions;
	}

	public Set getPapers() {
		return this.papers;
	}

	public void setPapers(Set papers) {
		this.papers = papers;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}
	
}