package com.qhit.biz.impl;

import java.util.ArrayList;

import com.qhit.bean.Direction;
import com.qhit.bean.ExamQuestion;
import com.qhit.bean.Stage;
import com.qhit.bean.Subject;
import com.qhit.biz.ExamQuestionBiz;
import com.qhit.dao.ExamQuestionDao;
import com.qhit.dao.impl.ExamQuestionDaoImpl;
import com.qhit.util.PageBean;

public class ExamQuestionBizImpl implements ExamQuestionBiz {

	private ExamQuestionDao eqd = new ExamQuestionDaoImpl();
	
	public ArrayList<Direction> getDirList() {
		// TODO Auto-generated method stub
		return eqd.getDirList();
	}

	public ArrayList<Stage> getStageList() {
		// TODO Auto-generated method stub
		return eqd.getStageList();
	}

	public int getCountBySubid(int subid) {
		// TODO Auto-generated method stub
		return eqd.getCountBySubid(subid);
	}

	public Direction getDirectionById(int did) {
		// TODO Auto-generated method stub
		return eqd.getDirectionById(did);
	}

	public ArrayList<Stage> getStageById(int staid) {
		// TODO Auto-generated method stub
		return eqd.getStageById(staid);
	}

	public ArrayList<Subject> getSubjectByDidAndStaid(int did, int staid) {
		// TODO Auto-generated method stub
		return eqd.getSubjectByDidAndStaid(did, staid);
	}

	public ArrayList<Direction> getDirList(int order) {
		// TODO Auto-generated method stub
		return eqd.getDirList(order);
	}

	public ArrayList<Stage> getStageList(int order) {
		// TODO Auto-generated method stub
		return eqd.getStageList(order);
	}

	public ArrayList<ExamQuestion> getExamQuestionByEsubid(int esubid) {
		// TODO Auto-generated method stub
		return eqd.getExamQuestionByEsubid(esubid);
	}

	public ArrayList<Subject> getSubjectById(int subid) {
		// TODO Auto-generated method stub
		return eqd.getSubjectById(subid);
	}

	public int addExamQuestion(ExamQuestion e,int esubid) {
		// TODO Auto-generated method stub
		return eqd.addExamQuestion(e, esubid);
	}

	public PageBean getExamQuestionPageBean(int p, int esubid) {
		// TODO Auto-generated method stub
		return eqd.getExamQuestionPageBean(p, esubid);
	}

	public ArrayList<ExamQuestion> getExamQuestionByEid(int eid) {
		// TODO Auto-generated method stub
		return eqd.getExamQuestionByEid(eid);
	}

	public int updateExamQuestion(ExamQuestion e, int esubid) {
		// TODO Auto-generated method stub
		return eqd.updateExamQuestion(e, esubid);
	}
	
}
