package com.qhit.bean;

import java.util.HashSet;
import java.util.Set;

/**
 * Paper entity. @author MyEclipse Persistence Tools
 */

public class Paper implements java.io.Serializable {

	// Fields

	private Integer pid;
	private Subject subject;
	private Classs classs;
	private Tatus tatus;
	private String pfirstType;
	private String ptitle;
	private String pstartTime;
	private String pfinishTime;
	private Integer pexamTime;
	private String ptotalScore;
	private Set stuPaperEqs = new HashSet(0);
	private Set scores = new HashSet(0);
	private Set paperEqs = new HashSet(0);
	private int yn;
	// Constructors

	/** default constructor */
	public Paper() {
	}

	/** minimal constructor */
	public Paper(Integer pid) {
		this.pid = pid;
	}

	/** full constructor */
	public Paper(Integer pid, Subject subject, Classs classs, Tatus tatus,
			String pfirstType, String ptitle, String pstartTime,
			String pfinishTime, Integer pexamTime, String ptotalScore,
			Set stuPaperEqs, Set scores, Set paperEqs) {
		this.pid = pid;
		this.subject = subject;
		this.classs = classs;
		this.tatus = tatus;
		this.pfirstType = pfirstType;
		this.ptitle = ptitle;
		this.pstartTime = pstartTime;
		this.pfinishTime = pfinishTime;
		this.pexamTime = pexamTime;
		this.ptotalScore = ptotalScore;
		this.stuPaperEqs = stuPaperEqs;
		this.scores = scores;
		this.paperEqs = paperEqs;
	}

	// Property accessors

	public Integer getPid() {
		return this.pid;
	}

	public void setPid(Integer pid) {
		this.pid = pid;
	}

	public Subject getSubject() {
		return this.subject;
	}

	public void setSubject(Subject subject) {
		this.subject = subject;
	}

	public Classs getClasss() {
		return this.classs;
	}

	public void setClasss(Classs classs) {
		this.classs = classs;
	}

	public Tatus getTatus() {
		return this.tatus;
	}

	public void setTatus(Tatus tatus) {
		this.tatus = tatus;
	}

	public String getPfirstType() {
		return this.pfirstType;
	}

	public void setPfirstType(String pfirstType) {
		this.pfirstType = pfirstType;
	}

	public String getPtitle() {
		return this.ptitle;
	}

	public void setPtitle(String ptitle) {
		this.ptitle = ptitle;
	}

	public String getPstartTime() {
		return this.pstartTime;
	}

	public void setPstartTime(String pstartTime) {
		this.pstartTime = pstartTime;
	}

	public String getPfinishTime() {
		return this.pfinishTime;
	}

	public void setPfinishTime(String pfinishTime) {
		this.pfinishTime = pfinishTime;
	}

	public Integer getPexamTime() {
		return this.pexamTime;
	}

	public void setPexamTime(Integer pexamTime) {
		this.pexamTime = pexamTime;
	}

	public String getPtotalScore() {
		return this.ptotalScore;
	}

	public void setPtotalScore(String ptotalScore) {
		this.ptotalScore = ptotalScore;
	}

	public Set getStuPaperEqs() {
		return this.stuPaperEqs;
	}

	public void setStuPaperEqs(Set stuPaperEqs) {
		this.stuPaperEqs = stuPaperEqs;
	}

	public Set getScores() {
		return this.scores;
	}

	public void setScores(Set scores) {
		this.scores = scores;
	}

	public Set getPaperEqs() {
		return this.paperEqs;
	}

	public void setPaperEqs(Set paperEqs) {
		this.paperEqs = paperEqs;
	}

	public int getYn() {
		return yn;
	}

	public void setYn(int yn) {
		this.yn = yn;
	}
	
}