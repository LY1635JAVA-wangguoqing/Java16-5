package com.qhit.bean;

import java.util.HashSet;
import java.util.Set;


/**
 * Tatus entity. @author MyEclipse Persistence Tools
 */

public class Tatus  implements java.io.Serializable {


    // Fields    

     private Integer taid;
     private String taname;
     private Set papers = new HashSet(0);


    // Constructors

    /** default constructor */
    public Tatus() {
    }

	/** minimal constructor */
    public Tatus(Integer taid) {
        this.taid = taid;
    }
    
    /** full constructor */
    public Tatus(Integer taid, String taname, Set papers) {
        this.taid = taid;
        this.taname = taname;
        this.papers = papers;
    }

   
    // Property accessors

    public Integer getTaid() {
        return this.taid;
    }
    
    public void setTaid(Integer taid) {
        this.taid = taid;
    }

    public String getTaname() {
        return this.taname;
    }
    
    public void setTaname(String taname) {
        this.taname = taname;
    }

    public Set getPapers() {
        return this.papers;
    }
    
    public void setPapers(Set papers) {
        this.papers = papers;
    }
   








}